package com.example.sensor_app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.regex.Pattern

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var serverIp: String = "192.168.0.109" // Default value, will be updated by user input
    private val serverPort = 5005         // <<== Replace with your PC's port number

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ipAddressEditText: EditText = findViewById(R.id.ipAddressEditText)
        val startButton: Button = findViewById(R.id.startButton)

        // Set default value for IP input field
        ipAddressEditText.setText(serverIp)

        // When the button is clicked, update the server IP and start sending sensor data
        startButton.setOnClickListener {
            val newIp = ipAddressEditText.text.toString()
            if (isValidIp(newIp)) {
                serverIp = newIp
                Toast.makeText(this, "Server IP updated: $serverIp", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Invalid IP address, please try again", Toast.LENGTH_SHORT).show()
            }
        }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        accelerometer?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        gyroscope?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return

        val message = when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> "ACC,${event.values[0]},${event.values[1]},${event.values[2]}"
            Sensor.TYPE_GYROSCOPE -> "GYRO,${event.values[0]},${event.values[1]},${event.values[2]}"
            else -> ""
        }

        if (message.isNotEmpty()) {
            sendUdp(message)
        }
    }

    private fun sendUdp(message: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                DatagramSocket().use { socket ->
                    val address = InetAddress.getByName(serverIp)
                    val buf = message.toByteArray()
                    val packet = DatagramPacket(buf, buf.size, address, serverPort)
                    socket.send(packet)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Error sending data", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun isValidIp(ip: String): Boolean {
        val ipPattern = Pattern.compile(
            "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\." +
                    "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\." +
                    "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\." +
                    "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
        )
        return ipPattern.matcher(ip).matches()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not needed
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
    }
}
